package week1.day1;

public class Calculator {
    public static void main(String[] args) {

        int x = Integer.parseInt(args[0]); //first arguments
        int y = Integer.parseInt(args[1]); //second arguments
        int sum = x + y;
        System.out.println("The sum of x and y is: " +sum);


    }

}
